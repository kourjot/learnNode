const params = new URLSearchParams(window.location.search);
const id = params.get("id");

function fetchCharacter(id) {
  fetch(`https://rickandmortyapi.com/api/character/${id}`)
    .then(res => res.json())
    .then(data => {
      displayCharacter(data);
    });
}

function displayCharacter(character) {
  const container = document.getElementById("character-detail");
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${character.image}" alt="${character.name}">
    <h2>${character.name}</h2>
    <p>Status: ${character.status}</p>
    <p>Species: ${character.species}</p>
    <p>Type: ${character.type || "Unknown"}</p>
    <p>Gender: ${character.gender}</p>
    <p>Origin: ${character.origin.name}</p>
    <p>Location: ${character.location.name}</p>
    <p>Episodes: ${character.episode.length}</p>
  `;
  container.appendChild(card);
}

function updateClock() {
  const now = new Date();
  const options = { weekday: "long", month: "long", day: "numeric" };
  const time = now.toLocaleTimeString();
  const date = now.toLocaleDateString("en-US", options);
  document.getElementById("clock").innerText = `${time} ${date}`;
}
setInterval(updateClock, 1000);

fetchCharacter(id);
